<?php include 'include/connection.php'; ?>

<?php 
      $rname_error=$email_error=$contact_error=$address_error=$password_error=$age_error="";
      $rname_color=$email_color=$contact_color=$address_color=$password_color=$age_color="";
    
    if(isset($_POST['send'])){
        $rname = $_POST['rname'];
        $email = $_POST['email'];
        $age = $_POST['age'];
        $gender = $_POST['gender'];
        $bloodgroup = $_POST['bloodgroup'];
        $contact = $_POST['contact'];
        $address = $_POST['address'];
        $password = $_POST['password'];
          if($rname ==""){
            $rname_error = "<p class='text-danger small'> please write your name here</p>";
            $rname_color = "is-invalid";
            }
        elseif(!preg_match("/^[A-ZA-z0-9 ]*$/",$rname)){
            $rname_error = "<p class='small text-danger'>only alphabets allowed</p>";
        }
        elseif($email ==""){
            $email_error = "<p class='text-danger small'>Search is empty please write your email</p>";
             $email_color = "is-invalid";
             }
         elseif(!preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix",$email)){
            $email_error = "<p class='small text-danger'>only @ allowed</p>";
        }
        elseif($age ==""){
            $age_error = "<p class='text-danger small'> please write your age here</p>";
             $age_color = "is-invalid";
            }
        elseif(!preg_match("/^[0-9]{2}$/",$age)){
            $age_error = "<p class='small text-danger'>only ten number allowed</p>";
        }
        elseif($contact ==""){
            $contact_error = "<p class='text-danger small'> please write your contact here</p>";
             $contact_color = "is-invalid";
            }
        elseif(!preg_match("/^[0-9]{10}$/",$contact)){
            $contact_error = "<p class='small text-danger'>only ten number allowed</p>";
        }
        
          if($address ==""){
            $address_error = "<p class='text-danger small'> please write your address here</p>";
            $address_color = "is-invalid";
            }
        elseif(!preg_match("/^[A-ZA-z ,]*$/",$address)){
            $address_error = "<p class='small text-danger'>only alphabet allowed</p>";
        }
        elseif($password ==""){
            $password_error = "<p class='text-danger small'> please write your contact here</p>";
             $password_color = "is-invalid";
            }
        elseif(!preg_match("/^[A-ZA-z0-9 @]*$/",$password)){
            $password_error = "<p class='small text-danger'>only ten number allowed</p>";
        }
        else{
             if($_FILES['images']['name']!=''){
                $image=rand(111111111,999999999).'_'.$_FILES['images']['name'];
                move_uploaded_file($_FILES['images']['tmp_name'],PRODUCT_IMAGE_SERVER_PATH.$image);
            }
            $sql="select * from receiver where (rname='$rname' and email='$email');";
            $res=mysqli_query($con,$sql);
            if (mysqli_num_rows($res) > 0) {
                    // output data of each row
                 $row = mysqli_fetch_assoc($res);
                 if (($rname==$row['rname']) && ($email==$row['email']))
                {
                    echo "<script>alert('Username and Email already exists')</script>";
                }
            }
             else{
            
                $query="insert into receiver(rname ,gender ,age ,bloodgroup ,email ,image ,contact ,address ,password  )value('$rname','$gender','$age','$bloodgroup','$email','$image','$contact','$address','$password')";
                $run=mysqli_query($con,$query);
                if($run){
                    echo"<script>alert('Successfully registered now you can login')</script>";
                    echo"<script>window.open('receiver_login.php','_self')</script>";
                }
           }
        }
    }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Hospital Registration Page |</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body class="bg-light">
    <?php include 'header/navigation.php'; ?>
    <div class="container-fluid mt-4">
        <div class="row w-100 p-0">
            <div class="col-lg-3"></div>
            <div class="col-lg-6">
                <div class="card " style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                    <div class="card-header bg-primary h4 text-white">Register Here(As a Receiver)</div>
                    <div class="card-body">
                        <form action="receiver_reg.php" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="rname">Name:</label>
                                <input type="text" class="form-control" <?php echo "$rname_color"; ?>name="rname" placeholder="enter your name here" value="<?php if(isset($_POST['send'])){echo"$rname";} ?>"><?php echo"$rname_error"; ?>
                            </div>
                            <div class="form-group">
                                <label for="rname">Gender:</label>
                                <div class="form-check form-check-inline">
                                    <input type="radio" class="form-check-input" name="gender" value="male" required>
                                    <label class="form-check-label" for="male">Male</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input type="radio" class="form-check-input" name="gender" value="female" required>
                                    <label class="form-check-label" for="female">Female</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="age">Age:</label>
                                <input type="number" class="form-control" <?php echo "$age_color"; ?> name="age" placeholder="enter your age here" value="<?php if(isset($_POST['send'])){echo"$age";} ?>"><?php echo"$age_error"; ?>
                            </div>
                            <div class="form-group">
                                <label for="bloodgroup">Blood Group:</label>
                                <select class="form-control" required name="bloodgroup">
                                    <option value="0">--Select Here--</option>
                                    <option>A+</option>
                                    <option>A-</option>
                                    <option>B+</option>
                                    <option>B-</option>
                                    <option>AB+</option>
                                    <option>AB-</option>
                                    <option>O+</option>
                                    <option>O-</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" class="form-control" <?php echo "$email_color"; ?> name="email" placeholder="enter your email here" value="<?php if(isset($_POST['send'])){echo"$email";} ?>"><?php echo"$email_error"; ?>
                            </div>
                            <div class="form-group">
                                <label for="images">Upload Image Here:</label>
                                <input type="file" required class="form-control-file" id="images" name="images">
                            </div>
                            <div class="form-group">
                                <label for="contact">Contact:</label>
                                <input type="text" class="form-control" <?php echo "$contact_color"; ?>name="contact" placeholder="enter your contact here" value="<?php if(isset($_POST['send'])){echo"$contact";} ?>"><?php echo"$contact_error"; ?>
                            </div>
                            <div class="form-group">
                                <label for="address">Address:</label>
                                <textarea name="address" class="form-control" <?php echo "$address_color"; ?>id="" cols="30" rows="4" placeholder="enter address here"><?php if(isset($_POST['send'])){echo"$address";} ?></textarea><?php echo"$address_error"; ?>
                            </div>
                            <div class="form-group">
                                <label for="password">Password:</label>
                                <input type="password" class="form-control" name="password" <?php echo "$password_color"; ?> placeholder="enter your password here" value="<?php if(isset($_POST['send'])){echo"$password";} ?>"><?php echo"$password_error"; ?>
                            </div>

                            <div class="form-group">
                                <button type="submit" class="btn btn-success btn-md" name="send">Register</button>
                                <a href="receiver_login.php" class="btn btn-primary btn-md">Back</a>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include 'include/footer.php';?>
</body>

</html>
