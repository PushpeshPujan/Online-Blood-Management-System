<?php
    session_start();
    session_destroy();
    header('location: receiver_login.php');
    die();
?>
