<?php include 'include/connection.php';
if(isset($_GET['hospital_id'])&& (!$_SESSION['email'])){
    header('location: receiver_login.php');
 } 
 if(isset($_GET['hospital_id'])&& ($_GET['blood_group'])){
     $_SESSION['hid']=$_GET['hospital_id'];
     $_SESSION['blood']=$_GET['blood_group'];
     $sql="select * from addblood where hospital_id='".$_SESSION['hid']."' and blood_name ='".urlencode($_SESSION['blood'])."'";
    $check=mysqli_query($con,$sql);
    while($res=mysqli_fetch_array($check)){
       $_SESSION['bl']=$res['blood_name']; 
       
    }
 }

$query="select * from receiver where email='".$_SESSION['email']."'";
$run=mysqli_query($con,$query);
while($row=mysqli_fetch_array($run)){
    $rname=$row['rname'];
    $receiver_id=$row['receiver_id'];
    $blood_group=$row['bloodgroup'];
    $age=$row['age'];
    $email=$row['email'];
    $contact=$row['contact'];
    $image=$row['image'];
    $gender=$row['gender'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <title>Receiver Request Page |</title>
</head>

<body class="bg-light">
    <?php include 'header/navigation.php';?>
    <div class="container-fluid mt-4 mb-4">
        <div class="row">
            <?php 
            if(isset($_POST['request'])){
                if(strcmp($_SESSION['bl'],$blood_group)==0){
                $rname=$_POST['rname'];
                $bloodgroup=$_POST['bloodgroup'];
                $age=$_POST['age'];
                $email=$_POST['email'];
                $contact=$_POST['contact'];
                $image=$_POST['image'];
             
                    //hecking for email already exists
                $sql="select * from request where (rname='$rname' and email='$email');";
                $res=mysqli_query($con,$sql);
                if (mysqli_num_rows($res) > 0) {
                    // output data of each row
                    $row = mysqli_fetch_assoc($res);
                    if (($rname==$row['rname']) && ($email==$row['email']))
                    {
                        echo "<script>alert('Already requested.')</script>";
                        echo "<script>window.open('index.php','_self')</script>";
                    }
                }
                else{
                    $hospital_id=$_SESSION['hid'];
                    $query="insert into request(rname,gender ,blood_group,age,email,contact,image,hospital_id)value('$rname','$gender','$bloodgroup','$age','$email','$contact','$image','$hospital_id')";
                    $run=mysqli_query($con,$query);
                    if($run){
                        echo "<script>alert('Your request has sent successfully')</script>";
                        echo "<script>window.open('index.php','_self')</script>";
                }
               }
              }
                else{
                    echo "<script>alert('Your bloodgroup is not matching as per request.Kindly request matching blood group.')</script>";
                    echo "<script>window.open('index.php','_self')</script>";
                }
            }
           ?>
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"></div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                <div class="card">
                    <div class="card-header bg-primary text-white h5">You Can Request now</div>
                    <div class="card-body">
                        <form action="receiver_req.php" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="rname">Receiver Name:</label>
                                <input type="text" class="form-control" value="<?php echo $rname ;?>" readonly name="rname">
                            </div>
                            <div class="form-group">
                                <label for="bloodgroup">Blood Group:</label>
                                <input type="text" name="bloodgroup" value="<?php echo $blood_group;?>" readonly class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="age">Age:</label>
                                <input type="number" name="age" value="<?php echo $age;?>" class="form-control" readonly>
                            </div>
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" class="form-control" value="<?php echo $email;?>" readonly name="email">
                            </div>
                            <div class="form-group">
                                <label for="contact">Contact:</label>
                                <input type="text" name="contact" class="form-control" value="<?php echo $contact;?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="image">Image:</label>
                                <input type="text" name="image" value="<?php echo $image; ?>" class="form-control" readonly>
                            </div>
                            <div class="form-group text-center">
                                <input type="submit" class="btn btn-success btn-md" name="request" value="Request">
                                <a href="home.php" class="btn btn-danger btn-md ml-3">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg- col-md-3 col-sm-3 col-xs-3"></div>
        </div>
    </div>
    <?php include 'include/footer.php';?>
</body>

</html>
