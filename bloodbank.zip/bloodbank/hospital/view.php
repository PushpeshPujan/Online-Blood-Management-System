<?php include'../include/connection.php';
    if(!isset($_SESSION['email']) && $_SESSION['email']=''){
        header('loaction: ../hospital_login.php');
    }
if(isset($_GET['view'])){
    $id=$_GET['view'];
$sql="select * from request where id='$id'";
$run=mysqli_query($con,$sql);
while($result=mysqli_fetch_array($run)){
    $rname=$result['rname'];
    $age=$result['age'];
    $contact=$result['contact'];
    $image=$result['image'];
    $email=$result['email'];
    $blood_group=$result['blood_group'];
}
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <title>View Page |</title>
</head>

<body class="bg-light">
    <?php include'../header/nav.php';?>
    <div class="container-fluid mt-4 mb-4">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"></div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); border:none;borer-radius:0px;">
                    <div class="card-header h4 bg-danger text-white text-center">Receiver Details</div>
                    <div class="card-body">
                        <table class="table table-responsive table-hover">
                            <tbody>
                                <tr>
                                    <th rowspan="5"><img src="../images/<?php echo $image;?>" alt="not available" class="img-fluid" height="150px" width="150px"></th>
                                    <th>Receiver Name:</th>
                                    <td><?php echo $rname;?></td>
                                </tr>
                                <tr>
                                    <th>Age :</th>
                                    <td><?php echo $age;?></td>
                                </tr>
                                <tr>
                                    <th>Blood Group :</th>
                                    <td><?php echo $blood_group; ?></td>
                                </tr>
                                <tr>
                                    <th>Contact No:</th>
                                    <td><?php echo $contact; ?></td>
                                </tr>
                                <tr>
                                    <th>Email:</th>
                                    <td><?php echo $email; ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="col-12 text-center"><a href="request.php" class="btn btn-success btn-md" style="width:100px;">Back</a></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"></div>
        </div>
    </div>
</body>

</html>
