<?php include'../include/connection.php';
    if(!isset($_SESSION['email']) && $_SESSION['email']=''){
        header('loaction: ../hospital_login.php');
    }
$email=$_SESSION['email'];
$sql="select * from hospital where email='$email'";
$run=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($run)){
$hospital_id=$row['hospital_id'];
$hname=$row['hname'];
$image=$row['image'];
$email=$row['email'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <title>Dashboard Page |</title>
</head>

<body class="bg-light">
    <?php include'../header/nav.php';?>
    <div class="modal fade" id="Modal">
        <div class="modal-dialog modal-lg modal-md modal-sm modal-xs">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Add Blood Samples Details Here</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <div class="card">
                    <div class="card-body">
                        <form action="dashboard.php" method="post" enctype="multipart/form-data">
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="bloodname">Blood Name:</label>
                                    <select name="bloodname" id="bloodname" class="form-control" required>
                                        <option value="0">--Select Here--</option>
                                        <option>A+</option>
                                        <option>A-</option>
                                        <option>B+</option>
                                        <option>B-</option>
                                        <option>AB+</option>
                                        <option>AB-</option>
                                        <option>O+</option>
                                        <option>O-</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="price">Price Per Bottle:</label>
                                    <input type="number" name="price" placeholder="please enter price per bottle here" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="qty">Quantity:</label>
                                    <select name="qty" id="qty" class="form-control" required>
                                        <option value="0">--Select Here--</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                <div class="form-group">
                                    <input type="submit" name="save" class="btn btn-success btn-md" value="Save">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <?php
        if(isset($_POST['save'])){
            $blood_name=$_POST['bloodname'];
            $price=$_POST['price'];
            $qty=$_POST['qty'];
           $query="insert into addblood(hospital_id,hname,blood_name,qty,price_per_bottle,image)value('$hospital_id','$hname','$blood_name','$qty','$price','$image')";
            $run=mysqli_query($con,$query);
        }
    ?>
            </div>
        </div>
    </div>
    <div class="container-fluid mt-4 mb-4">
        <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); border:none;borer-radius:0px;">
            <div class="card-body">
                <div class="col-12">
                    <ul class="navbar-nav">
                        <li class="nav-item ml-2 mt-4"> <img src="../images/<?php echo $image;?>" alt="not available" class="rounded-circle" height="80px" width="100px"></li>
                        <li class="nav-item ml-2 h4"><?php echo $email;?></li>
                        <li class="nav-item ml-auto h4">Hi , <?php echo $hname;?></li>
                    </ul>
                </div>
                <div class="col-12 text-center mt-4">
                    <?php
                if($run){
                echo "<div class='alert alert-success'>Thank you for Blood Sample addition</div>";
            }
           ?>
                </div>
                <div class="col-12 text-center mt-4 mb-4">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#Modal">
                        Add Blood Details</button>
                    <a href="request.php" class="btn btn-danger btn-md ml-2">View Requests</a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
