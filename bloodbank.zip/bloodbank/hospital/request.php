<?php include'../include/connection.php';
    if(!isset($_SESSION['email']) && $_SESSION['email']=''){
        header('loaction: ../hospital_login.php');
    }
$email=$_SESSION['email'];
$sql="select * from hospital where email='$email'";
$run=mysqli_query($con,$sql);
while($result=mysqli_fetch_array($run)){
    $hospital_id=$result['hospital_id'];
    $hname=$result['hname'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <title>View Request Page |</title>
</head>

<body class="bg-light">
    <?php include'../header/nav.php';?>
    <div class="container-fluid mt-4 mb-4">
        <div class="col-12 text-center">
            <a href="dashboard.php" class="btn btn-success btn-md" style="width:100px;">Back</a>
        </div>
        <div class="row mt-4">
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2"></div>
            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
                <div class="card" style="border:0px;border-radius:0px;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                    <div class="card-body">
                        <table class="table table-bordered table-striped table-responsive table-hover">
                            <thead>
                                <tr>
                                    <th>Receiver Name</th>
                                    <th class="text-center">Age</th>
                                    <th class="text-center">Gender</th>
                                    <th class="text-center">Blood Group</th>
                                    <th class="text-center">Contact No</th>
                                    <th class="text-center">Email</th>
                                    <th class="text-center">Date of Request</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    $query="select * from request where hospital_id='$hospital_id' order by doc desc";
                                    $run=mysqli_query($con,$query);
                                    $check=mysqli_num_rows($run);
                                    if($check>0){
                                    while($row=mysqli_fetch_array($run)){
                                
                                ?>
                                <tr>
                                    <td><?php echo $row['rname'];?></td>
                                    <td><?php echo $row['age'];?></td>
                                    <td><?php echo $row['gender'];?></td>
                                    <td><?php echo $row['blood_group'];?></td>
                                    <td><?php echo $row['contact'];?></td>
                                    <td><?php echo $row['email'];?></td>
                                    <td><?php echo date("Y-m-d",strtotime($row['doc'])); ?></td>
                                    <td><a href="view.php?view=<?php echo $row['id'];?>" class="btn btn-danger badge-pill badge-danger" style="width:80px;">View</a></td>
                                </tr>
                                <?php } } else {
                                echo "<div class='alert alert-danger'>You don't have any request till now. Thank you.</div>";}
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2"></div>
        </div>
    </div>

</body>

</html>
