<?php include 'include/connection.php';?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <title>Home Page |</title>
</head>

<body class="bg-light">
    <?php include'header/navigation.php';?>
    <?php include'header/carousel.php';?>

    <div class="container-fluid mt-4 mb-4">
        <div class="col-12 mt-4 text-center text-muted h2">Our Donors
        </div>
        <div class="row mt-4">
            <?php
                $sql="select * from addblood order by doc desc";
                $run=mysqli_query($con,$sql);
                while($row=mysqli_fetch_array($run)){
            ?>
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 mt-2 mb-2">
                <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                    <img src="images/<?php echo $row['image']; ?>" class="card-img-top" height="200px">
                    <div class="card-body">
                        <p class="card-text text-primary text-center"><?php echo $row['hname'];?></p>
                        <p class="card-text"><b>Blood Group : </b><?php echo $row['blood_name'];?></p>
                        <p class="card-text"><b>Price Per Bottle : </b>RS.<?php echo $row['price_per_bottle'];?></p>
                        <p class="card-text"><b>Blood Uploaded : </b><?php echo date("D d-m-Y",strtotime($row['doc']));?></p>
                        <a href="receiver_req.php?hospital_id=<?php echo $row['hospital_id'];?>&blood_group=<?php echo $row['blood_name'];?>" class="btn btn-primary btn-block" name="hid">Request Sample</a>
                    </div>
                </div>
            </div>
            <?php } ?>

        </div>
    </div>
    <?php include 'include/footer.php';?>
</body>

</html>
