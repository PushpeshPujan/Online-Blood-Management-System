-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 25, 2020 at 07:40 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bloodbank`
--

-- --------------------------------------------------------

--
-- Table structure for table `addblood`
--

CREATE TABLE `addblood` (
  `id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `hname` varchar(100) NOT NULL,
  `blood_name` varchar(30) NOT NULL,
  `qty` int(11) NOT NULL,
  `price_per_bottle` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `doc` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addblood`
--

INSERT INTO `addblood` (`id`, `hospital_id`, `hname`, `blood_name`, `qty`, `price_per_bottle`, `image`, `doc`) VALUES
(1, 1, 'Fortis Hospital', 'A+', 2, 200, 'fortis.jpg', '2020-10-25 18:01:54'),
(4, 1, 'Fortis Hospital', 'O+', 2, 600, 'fortis.jpg', '2020-10-25 18:02:11'),
(5, 2, 'Ruby General Hospital', 'B+', 4, 1200, 'ruby.jpg', '2020-10-25 18:02:23'),
(6, 2, 'Ruby General Hospital', 'O+', 4, 1000, 'ruby.jpg', '2020-10-25 18:02:43'),
(7, 2, 'Ruby General Hospital', 'AB-', 1, 1700, 'ruby.jpg', '2020-10-25 18:02:58'),
(8, 4, 'Apollo Hospital', 'O-', 2, 3700, '119387148_apollo.jpg', '2020-10-25 18:12:30'),
(9, 5, 'Medanta Hospital,Delhi', 'B-', 3, 2100, '759988816_medanta.jpg', '2020-10-25 18:14:34'),
(10, 6, 'Aster CMI Hospital', 'AB+', 1, 2300, '847722449_astercmi.jpg', '2020-10-25 18:16:52');

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `hospital_id` int(11) NOT NULL,
  `hname` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `image` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`hospital_id`, `hname`, `email`, `contact`, `image`, `address`, `password`) VALUES
(1, 'Fortis Hospital', 'fortis@gmail.com', '7767453221', 'fortis.jpg', 'Kolkata', '123'),
(2, 'Ruby General Hospital', 'ruby@gmail.com', '9706543234', 'ruby.jpg', 'Kolkata', 'ruby123'),
(3, 'Cooper Hospital', 'cooper@gmail.com', '9706543234', 'cooper.jpg', 'Delhi', 'cooper'),
(4, 'Apollo Hospital', 'apollo@gmail.com', '9852773704', '119387148_apollo.jpg', 'Mumbai,Maharashtra', 'apollo'),
(5, 'Medanta Hospital,Delhi', 'medanta@gmail.com', '8986754320', '759988816_medanta.jpg', 'New Delhi, India', 'medanta'),
(6, 'Aster CMI Hospital', 'aster@gmail.com', '8409765432', '847722449_astercmi.jpg', 'Bangaluru,Karnataka', 'aster123');

-- --------------------------------------------------------

--
-- Table structure for table `receiver`
--

CREATE TABLE `receiver` (
  `receiver_id` int(11) NOT NULL,
  `rname` varchar(30) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `age` int(11) NOT NULL,
  `bloodgroup` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `receiver`
--

INSERT INTO `receiver` (`receiver_id`, `rname`, `gender`, `age`, `bloodgroup`, `email`, `image`, `contact`, `address`, `password`) VALUES
(1, 'Aniket Bahera', 'male', 23, 'B+', 'aniket@gmail.com', '252258832_tshirt.jpeg', '8877662377', 'Patna,Bihar', '123456'),
(2, 'Saket Kumar', 'male', 24, 'AB+', 'saket@gmail.com', '339546744_fsmen.jfif', '8409462345', 'Patna, Bihar', 'saket123'),
(3, 'Piyush Kumar', 'male', 25, 'B+', 'piyush@gmail.com', '573998581_jeans.jpeg', '7602345671', 'Mukherjee Nagar, Delhi', 'piyush@123'),
(12, 'Anand Bhaskar', 'male', 25, 'A+', 'anand@gmail.com', '665793532_fsh40.jfif', '9852773704', 'Noida,Delhi', 'an'),
(13, 'Salman Rashid', 'male', 36, 'A+', 'salman@gmail.com', '192309673_man.jfif', '8986754320', 'Vishakhapattanam', '123'),
(14, 'Sandhi Singh', 'female', 23, 'O+', 'sandhi@gmail.com', '341596289_sandhi.jpeg', '8986754320', 'Purnea,Bihar', 'sandhi123'),
(15, 'Rakesh Kumar', 'male', 23, 'O-', 'rakesh@gmail.com', '977382680_pi.jpg', '9852773704', 'Lucknow,Uttar Pradesh', 'rakesh');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `id` int(11) NOT NULL,
  `rname` varchar(30) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `blood_group` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `image` varchar(255) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `doc` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`id`, `rname`, `gender`, `blood_group`, `age`, `email`, `contact`, `image`, `hospital_id`, `doc`) VALUES
(1, 'Aniket Bahera', 'male', 'B+', 23, 'aniket@gmail.com', '8877662377', '252258832_tshirt.jpeg', 2, '2020-10-25 14:46:25'),
(2, 'Salman Rashid', 'male', 'A+', 36, 'salman@gmail.com', '8986754320', '192309673_man.jfif', 1, '2020-10-25 14:18:35'),
(3, 'Sandhi Singh', 'female', 'O+', 23, 'sandhi@gmail.com', '8986754320', '341596289_sandhi.jpeg', 1, '2020-10-25 14:23:14'),
(4, 'Rakesh Kumar', 'male', 'O-', 23, 'rakesh@gmail.com', '9852773704', '977382680_pi.jpg', 4, '2020-10-25 18:20:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addblood`
--
ALTER TABLE `addblood`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`hospital_id`);

--
-- Indexes for table `receiver`
--
ALTER TABLE `receiver`
  ADD PRIMARY KEY (`receiver_id`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addblood`
--
ALTER TABLE `addblood`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `hospital`
--
ALTER TABLE `hospital`
  MODIFY `hospital_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `receiver`
--
ALTER TABLE `receiver`
  MODIFY `receiver_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
