<nav class="navbar navbar-expand-md navbar-expand-lg navbar-expand-sm navbar-expand-xs bg-primary navbar-dark">
    <a class="navbar-brand text-white" href="../hospital/dashboard.php">Dashboard</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#Navbar">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="Navbar">
        <ul class="navbar-nav ml-auto">
            <?php if(isset($_SESSION['email'])&& $_SESSION['email']!=''){?>

            <li class='nav-item'>
                <a class='btn btn-danger btn-md' href='hospital_logout.php'>Logout</a>
            </li>
            <?php  }?>
        </ul>
    </div>
</nav>
