   <nav class="navbar navbar-expand-md navbar-expand-lg navbar-expand-sm navbar-expand-xs bg-info sticky-top">
       <a class="navbar-brand text-white" href="index.php">Blood Bank</a>
       <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#Navbar">
           <span class="navbar-toggler-icon"></span>
       </button>
       <div class="collapse navbar-collapse" id="Navbar">
           <ul class="navbar-nav ml-auto">
               <?php if(isset($_SESSION['email'])&& $_SESSION['email']!=''){
           $sql="select * from receiver where email='".$_SESSION['email']."'";
           $run=mysqli_query($con,$sql);
           while($result=mysqli_fetch_array($run)){
               $rname=$result['rname'];
               $image=$result['image'];
           } 
        ?>
               <li class="nav-item ml-auto h4 ml-2 mr-2"> <img src="images/<?php echo $image;?>" alt="not available" class="rounded-circle" height="60px" width="60px"></li>
               <li class="nav-item ml-auto h4 text-white mr-2">Hi , <?php echo $rname;?></li>

               <li class="nav-item">
                   <a class="btn btn-danger btn-md" href="receiver_logout.php">Logout</a>
               </li>
               <?php  } else {?>
               <li class="nav-item">
                   <a class="nav-link text-white" href="index.php">Home</a>
               </li>
               <li class="nav-item">
                   <a class="nav-link text-white" href="contact.php">Contact</a>
               </li>
               <li class="nav-item">
                   <div class="btn-group">
                       <button type="button" class="btn btn-danger">Login</button>
                       <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown">
                       </button>
                       <div class="dropdown-menu">
                           <a class="dropdown-item" href="hospital_login.php">As a Hospital</a>
                           <a class="dropdown-item" href="receiver_login.php">As a Receiver</a>
                       </div>
                   </div>
               </li>
               <?php } ?>
           </ul>
       </div>
   </nav>
